# CloseRoom V3 — video + floating chat

A temporary two-person browser video call with a chat panel that stays over the video. It is designed for phones and starts with the microphone muted.

## What's included
- One-click room creation and invite-link copying (random 96-bit room ID).
- Two-person room limit and a shared room password.
- Direct WebRTC video/audio between browsers; the server relays only temporary SDP/ICE signaling.
- Encrypted WebRTC DataChannel for chat (DTLS); WebRTC media uses encrypted SRTP.
- Full-viewport video stage with floating local camera preview.
- Floating message bubbles appear over the video for **10 seconds**. Tap a bubble to open the chat drawer.
- Swipe the chat drawer down or tap Close to return to the full video view. The video keeps running while the drawer is open.
- Full-screen button, microphone mute/unmute (muted by default), camera on/off, front/rear camera switch, and end-session button.
- No database, cookies, localStorage, IndexedDB or persistent chat history. Chat messages are held in page memory and cleared when the session ends.
- Switching tabs, minimizing, closing or leaving ends the session. Server-side room state is in memory and expires after 30 minutes.

## Important privacy notes
- HTTPS/WSS protects the connection to the signaling server. The server receives the room password for authentication and sees room IDs, connection timing, IP/network metadata and temporary SDP/ICE signaling. It does not receive the peer-to-peer chat text or media stream.
- WebRTC encrypts peer media with SRTP and DataChannel traffic with DTLS. This is transport encryption; this project has not had an independent security audit and should not be described as a formally audited end-to-end encrypted messenger.
- Set a strong `ROOM_PASSWORD` environment variable in Render and share it separately from the invite link. Do not use `786786` for a private conversation.
- STUN is configured, but TURN is not included. Some mobile carriers or restrictive NATs may need a TURN service for reliable calls. Without TURN, a call may fail on some networks.
- A browser cannot guarantee instant cleanup if the phone loses power, the OS kills the browser, or the network disappears. WebSocket heartbeat detects many unexpected disconnects, but mobile background events may be delayed.
- This app deliberately ends the session on `visibilitychange` to hidden. That includes switching tabs or minimizing; browser permission prompts and OS-level interruptions can also affect visibility.
- A website cannot prevent screenshots, screen recordings, notification previews, or copies made by a participant.

## Deploy to Render when the GitHub repository contains the ZIP only
This GitHub repository workflow expects the ZIP archive itself at the repository root.

1. Upload/replace `close-room-private-video-chat-v3.zip` in the GitHub repository root. Do not put it inside another folder.
2. In Render → your Web Service → Settings → Build & Deploy, set:
   - **Root Directory:** blank
   - **Build Command:** `unzip -o close-room-private-video-chat-v3.zip -d . && npm install`
   - **Start Command:** `npm start`
3. In Render → Environment, set `ROOM_PASSWORD` to a long unique password (at least 16 characters is recommended). Share it separately from the invite URL.
4. Save and choose **Manual Deploy → Deploy latest commit**.
5. Open the Render HTTPS URL. One person creates a room and copies the invite link; send the password separately. The second person opens the link and enters the password.

If you instead upload the extracted files directly to GitHub (with `package.json` in the repository root), use `npm install` as the Build Command. Do not mix the two layouts.

## Run locally in Termux
```sh
pkg update
pkg install nodejs-lts unzip
cd /storage/emulated/0/chatbot
unzip -o close-room-private-video-chat-v3.zip -d .
npm install
ROOM_PASSWORD='use-a-long-private-password' npm start
```
Open `http://127.0.0.1:3000`. For a second phone to connect over the internet, deploy to an HTTPS host. A local `localhost` link only works on the same device.

## Network / quality
The app requests up to 1080p at 30 fps, but actual quality depends on both devices, camera capability, browser support and available bandwidth. The browser/network may negotiate a lower resolution. Video is shown edge-to-edge (`object-fit: cover`), which can crop some edges of a different aspect ratio. STUN-only connectivity is not guaranteed on every carrier; add a trusted TURN provider if calls cannot connect reliably.
