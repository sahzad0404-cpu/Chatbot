const http = require("http");
const path = require("path");
const express = require("express");
const { WebSocketServer, WebSocket } = require("ws");
const crypto = require("crypto");

const app = express();
app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Permissions-Policy", "camera=(self), microphone=(self)");
  res.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self' ws: wss:; media-src 'self' blob:; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'");
  next();
});
app.get("/health", (_req, res) => res.status(200).send("ok"));
app.use(express.static(path.join(__dirname, "public"), { etag: false, maxAge: 0 }));

const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true, maxPayload: 70000 });
const rooms = new Map();
const ROOM_PASSWORD = process.env.ROOM_PASSWORD || "786786";
const PORT = process.env.PORT || 3000;
const ROOM_TTL = 30 * 60 * 1000;

const validRoom = id => typeof id === "string" && /^[a-f0-9]{24}$/.test(id);
const send = (ws, data) => {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
};
function endRoom(id, reason, notify = true) {
  const room = rooms.get(id);
  if (!room || room.ended) return;
  room.ended = true;
  if (notify) for (const client of room.clients) send(client, { type: "ended", reason });
  for (const client of room.clients) {
    client.endedByRoom = true;
    try { client.close(1000, "Session ended"); } catch (_) {}
  }
  room.clients.clear();
  rooms.delete(id);
}
server.on("upgrade", (req, socket, head) => {
  let url;
  try { url = new URL(req.url, "http://localhost"); } catch { socket.destroy(); return; }
  const id = url.searchParams.get("room");
  if (url.pathname !== "/socket" || !validRoom(id)) return socket.destroy();
  wss.handleUpgrade(req, socket, head, ws => {
    ws.roomId = id;
    wss.emit("connection", ws, req);
  });
});

wss.on("connection", ws => {
  const id = ws.roomId;
  let room = rooms.get(id);
  if (!room) {
    room = { clients: [], ended: false, created: Date.now() };
    rooms.set(id, room);
  }
  if (room.ended || room.clients.length >= 2) {
    send(ws, { type: "error", message: "This room already has two people or has ended. Create a new room." });
    ws.close(1008, "Room unavailable");
    return;
  }
  room.clients.push(ws);
  ws.authed = false;
  ws.isAlive = true;
  ws.on("pong", () => { ws.isAlive = true; });

  ws.on("message", raw => {
    let data;
    try { data = JSON.parse(raw.toString()); } catch { return; }

    if (data.type === "join") {
      if (ws.authed) return;
      if (typeof data.password !== "string" || data.password !== ROOM_PASSWORD) {
        send(ws, { type: "error", message: "Incorrect room password." });
        ws.close(1008, "Authentication failed");
        return;
      }
      ws.authed = true;
      const members = room.clients.filter(client => client.authed);
      if (members.length === 1) {
        send(ws, { type: "waiting" });
      } else if (members.length === 2) {
        members.forEach((client, index) => send(client, {
          type: "ready",
          initiator: index === 0
        }));
      }
      return;
    }

    if (!ws.authed || room.ended) return;
    if (data.type === "leave") {
      endRoom(id, "The other person left or closed the session.");
      return;
    }

    const allowed = new Set(["offer", "answer", "ice"]);
    if (allowed.has(data.type)) {
      const peer = room.clients.find(client => client !== ws && client.authed);
      if (!peer) return;
      const payload = JSON.stringify({ type: data.type, payload: data.payload });
      if (payload.length <= 65000) send(peer, JSON.parse(payload));
    }
  });

  ws.on("close", () => {
    const current = rooms.get(id);
    if (!current || current.ended || ws.endedByRoom) return;
    const wasAuthed = ws.authed;
    current.clients = current.clients.filter(client => client !== ws);
    if (wasAuthed) endRoom(id, "The other person disconnected. This session has ended.");
    else if (current.clients.length === 0) rooms.delete(id);
  });
  ws.on("error", () => {
    if (ws.authed) endRoom(id, "Connection error. This session has ended.");
  });
});

const heartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (ws.isAlive === false) { ws.terminate(); continue; }
    ws.isAlive = false;
    try { ws.ping(); } catch {}
  }
  const now = Date.now();
  for (const [id, room] of rooms) {
    if (now - room.created > ROOM_TTL) endRoom(id, "This room expired. Create a new one.");
  }
}, 15000);

server.listen(PORT, "0.0.0.0", () => console.log(`Private video chat listening on ${PORT}`));
function shutdown() {
  clearInterval(heartbeat);
  for (const id of [...rooms.keys()]) endRoom(id, "Server restarting. This session has ended.");
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 5000).unref();
}
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
