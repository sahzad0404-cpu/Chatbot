# CloseRoom V10

Private two-person WebRTC video and ephemeral chat.

## V9 focused fixes
- Removed the visibility-change handler that ended calls whenever Android Chrome/backgrounding, keyboard interactions, or app switching hid the page.
- A temporary peer disconnect no longer immediately destroys the entire room.
- When one participant leaves/disconnects, the other participant stays in a waiting state; the same invite and password can be used to rejoin.
- Rooms are created server-side and their invite link expires after five hours from creation.
- Explicit Leave exits only that participant; it does not invalidate the invite or force the other participant out.
- Starts with a Full HD (1080p) / 30fps camera target for the best available quality on the device.
- Adds adaptive sending: monitors WebRTC network statistics and steps bitrate, frame rate, and encoded resolution down only after repeated poor samples; restores quality gradually after sustained good samples.
- On supported Android browsers, a low battery while discharging caps video workload; normal quality returns when battery/network conditions improve.
- Keeps the existing V9 screens, chat behavior, room flow, and settings/UI unchanged.

## Deploy on Render
Root Directory: blank
Build Command:
```bash
unzip -o close-room-private-video-chat-v10*.zip -d . && npm install
```
Start Command:
```bash
npm start
```
Set `ROOM_PASSWORD` in Render environment variables. The same password is required by both participants; share it separately from the invite link.

## Notes
Room records are held in server memory. A Render process restart/redeploy clears active room records and connected calls, so a fresh room will be required after a server restart. The five-hour lifetime applies while the same server process remains running. No TURN relay is configured; restrictive carrier NATs may still prevent some direct WebRTC connections. Full HD depends on the phone camera/browser and available network; the browser may choose a lower capture mode if the device cannot provide 1080p. Battery Status and Network Information APIs are not exposed by every Android browser, so WebRTC congestion control remains the fallback when those signals are unavailable.
