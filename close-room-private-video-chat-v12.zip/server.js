const http = require("http");
const path = require("path");
const express = require("express");
const { WebSocketServer, WebSocket } = require("ws");
const crypto = require("crypto");

const app = express();
app.disable("x-powered-by");
app.use((req, res, next) => {
  res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Permissions-Policy", "camera=(self), microphone=(self)");
  res.setHeader("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self' ws: wss:; media-src 'self' blob:; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'");
  next();
});
app.get("/health", (_req, res) => res.status(200).send("ok"));
app.post("/api/rooms", (_req, res) => {
  const id = crypto.randomBytes(12).toString("hex");
  rooms.set(id, { clients: [], created: Date.now() });
  res.status(201).json({ roomId: id, expiresInMs: ROOM_TTL });
});
app.use(express.static(path.join(__dirname, "public"), { etag: false, maxAge: 0 }));

const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true, maxPayload: 70000 });
const rooms = new Map();
const ROOM_PASSWORD = process.env.ROOM_PASSWORD || "786786";
const PORT = process.env.PORT || 3000;
const ROOM_TTL = 5 * 60 * 60 * 1000;
const validRoom = id => typeof id === "string" && /^[a-f0-9]{24}$/.test(id);
const send = (ws, data) => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); };
function roomFor(id) {
  let room = rooms.get(id);
  if (!room) { room = { clients: [], created: Date.now() }; rooms.set(id, room); }
  return room;
}
function notifyPeerLeft(room, departing) {
  for (const client of room.clients) if (client !== departing && client.authed) send(client, { type: "peer-left", message: "The other person left. Waiting for them to rejoin…" });
}
function removeClient(room, client, notify = true) {
  if (!room) return;
  const existed = room.clients.includes(client);
  room.clients = room.clients.filter(item => item !== client);
  if (existed && notify && client.authed) notifyPeerLeft(room, client);
  // Keep the room ID/password valid for the full five-hour invitation window.
}
function pairRoom(room) {
  const members = room.clients.filter(client => client.authed && client.readyState === WebSocket.OPEN);
  if (members.length === 2) members.forEach((client, index) => send(client, { type: "ready", initiator: index === 0 }));
  else if (members.length === 1) send(members[0], { type: "waiting" });
}
server.on("upgrade", (req, socket, head) => {
  let url;
  try { url = new URL(req.url, "http://localhost"); } catch { socket.destroy(); return; }
  const id = url.searchParams.get("room");
  if (url.pathname !== "/socket" || !validRoom(id)) return socket.destroy();
  wss.handleUpgrade(req, socket, head, ws => { ws.roomId = id; wss.emit("connection", ws, req); });
});

wss.on("connection", ws => {
  const id = ws.roomId;
  const room = roomFor(id);
  if (room.clients.length >= 2) {
    send(ws, { type: "error", message: "This room already has two connected people. Please wait for a place to open." });
    ws.close(1008, "Room full"); return;
  }
  room.clients.push(ws);
  ws.authed = false;
  ws.isAlive = true;
  ws.on("pong", () => { ws.isAlive = true; });
  ws.on("message", raw => {
    let data;
    try { data = JSON.parse(raw.toString()); } catch { return; }
    if (data.type === "join") {
      if (ws.authed) return;
      if (typeof data.password !== "string" || data.password !== ROOM_PASSWORD) {
        send(ws, { type: "error", message: "Incorrect room password." });
        ws.close(1008, "Authentication failed"); return;
      }
      ws.authed = true;
      pairRoom(room);
      return;
    }
    if (!ws.authed) return;
    if (data.type === "leave") {
      removeClient(room, ws, true);
      ws.leftIntentionally = true;
      try { ws.close(1000, "You left the room"); } catch {}
      return;
    }
    if (["offer", "answer", "ice"].includes(data.type)) {
      const peer = room.clients.find(client => client !== ws && client.authed && client.readyState === WebSocket.OPEN);
      if (!peer) return;
      const payload = JSON.stringify({ type: data.type, payload: data.payload });
      if (payload.length <= 65000) send(peer, JSON.parse(payload));
    }
  });
  ws.on("close", () => {
    const current = rooms.get(id);
    if (!current || ws.leftIntentionally) return;
    removeClient(current, ws, true);
  });
  ws.on("error", () => {
    const current = rooms.get(id);
    if (current) removeClient(current, ws, true);
  });
});

const heartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (ws.isAlive === false) { ws.terminate(); continue; }
    ws.isAlive = false;
    try { ws.ping(); } catch {}
  }
  const now = Date.now();
  for (const [id, room] of rooms) if (now - room.created >= ROOM_TTL) {
    for (const client of room.clients) { send(client, { type: "ended", reason: "This invite expired after five hours. Create a new room." }); try { client.close(1000, "Room expired"); } catch {} }
    rooms.delete(id);
  }
}, 20000);

server.listen(PORT, "0.0.0.0", () => console.log(`Private video chat listening on ${PORT}`));
function shutdown() {
  clearInterval(heartbeat);
  for (const [id, room] of rooms) {
    for (const client of room.clients) { send(client, { type: "ended", reason: "The server restarted. Please rejoin using the same invite if it is still valid." }); try { client.close(1012, "Server restarting"); } catch {} }
    rooms.delete(id);
  }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 5000).unref();
}
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
