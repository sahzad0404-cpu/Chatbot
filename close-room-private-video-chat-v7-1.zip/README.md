# CloseRoom V6 — mobile keyboard and viewport fix

A temporary two-person browser video call with peer-to-peer WebRTC video and an ephemeral chat. The microphone starts muted.

## What's included
- Random room IDs, two-person rooms, invite links and shared room password.
- Direct WebRTC video/audio between browsers; server relays temporary SDP/ICE signaling.
- WebRTC DataChannel for chat; messages remain in page memory and are cleared when the session ends.
- Full-screen video with floating local camera preview, quick-message composer and full Messages view.
- Floating message bubbles: maximum three, each expires after 40 seconds.
- Mobile Chrome keyboard handling using `100dvh` and `window.visualViewport` resize/scroll events. The visible app viewport, quick composer and full-chat input resize with the keyboard.
- Mobile fullscreen uses an app-level immersive layout instead of the native Fullscreen API, avoiding Android Chrome's fullscreen-exit prompt when the keyboard opens.
- Camera, microphone, camera-switch and end-session controls.

## Mobile fixes in V6
- Quick-message input and send button stay at the bottom of the visible viewport, immediately above the virtual keyboard.
- Video, quick composer and full Messages views recalculate height on keyboard open/close, orientation changes and visual viewport scrolling.
- Floating message bubbles stay in a bounded lower video lane, reserve space for the local PiP and status UI, and scroll if their content is taller than the available area.
- On quick compose, bubbles remain within the visible video stage and away from the PiP preview.
- On phones, the Full button uses CSS immersive mode rather than native browser fullscreen; focusing a message field therefore does not intentionally request/exit native fullscreen.

## Privacy and network notes
- HTTPS/WSS protects the signaling connection. The server receives the room password for authentication and sees room IDs, connection timing, IP/network metadata and temporary SDP/ICE signaling.
- WebRTC encrypts peer media with SRTP and DataChannel traffic with DTLS. This is transport encryption; the project has not had an independent security audit.
- Set a strong `ROOM_PASSWORD` in Render and share it separately from the invite URL. Do not use a short default password for private conversations.
- STUN is configured, but TURN is not included. Some mobile carriers or restrictive NATs may need a TURN service for reliable calls.
- A browser cannot guarantee instant cleanup if the phone loses power, the OS kills Chrome, or the network disappears. Browser background events may be delayed.
- Screenshots, screen recordings, notification previews and participant-made copies cannot be prevented.

## Deploy to Render when GitHub contains the ZIP only
Upload `close-room-private-video-chat-v6.zip` to the root of the GitHub repository. In Render → Web Service → Settings → Build & Deploy use:
- **Root Directory:** blank
- **Build Command:** `unzip -o close-room-private-video-chat-v6.zip -d . && npm install`
- **Start Command:** `npm start`

Set `ROOM_PASSWORD` to a long unique password (16+ characters recommended), save, then choose **Manual Deploy → Deploy latest commit**.

If you upload the extracted files directly to GitHub instead, put `package.json` in the repository root and use `npm install` as the Build Command. Do not mix the two layouts.

## Run locally in Termux
```sh
pkg update
pkg install nodejs-lts unzip
cd /storage/emulated/0/chatbot
unzip -o close-room-private-video-chat-v6.zip -d .
npm install
ROOM_PASSWORD='use-a-long-private-password' npm start
```
Open `http://127.0.0.1:3000`. A localhost URL only works on that same device; use an HTTPS deployment for a second phone over the internet.

## Video quality
The app requests up to 1080p at 30 fps, but actual quality depends on both devices, camera capability, browser support and network conditions. STUN-only connectivity is not guaranteed on every carrier; add a trusted TURN provider if calls cannot connect reliably.


## V6 mobile fixes
- Quick Message uses the Android Chrome visual viewport and pins the composer directly above the keyboard.
- The upper video area sizes to the actual composer height; the separate Messages drawer is unchanged.
- Dismissing the keyboard or blurring the quick-message input closes Quick Message and restores the normal call screen.
- Resized video surfaces use a black background with no border or outline.
- Floating message toasts remain in the lower lane of the upper video area.
- Fullscreen button requests browser fullscreen where supported, with an app-level immersive fallback.
- Room creation attempts to copy the invite link immediately; End asks for confirmation to reduce accidental exits.

Mobile keyboard/fullscreen behaviour still needs a real two-phone Android Chrome test; static checks cannot reproduce every OEM keyboard/browser combination.
