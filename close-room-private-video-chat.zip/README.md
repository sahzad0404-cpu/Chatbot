# CloseRoom — private two-person video + chat

A temporary browser app for exactly two people. Video, audio and chat travel directly between browsers over WebRTC. The server only authenticates the room and relays temporary WebRTC signaling messages (SDP/ICE); it does not receive chat text or media and does not use a database.

## Features
- Random 96-bit room ID and one-click invite-link copy.
- Shared room password (sent only over HTTPS/WSS).
- Two-person room limit.
- Peer-to-peer video/audio using WebRTC; chat uses an encrypted WebRTC DataChannel.
- Local floating camera preview, remote video, mute, camera toggle and end-session controls.
- No database, cookies, localStorage, IndexedDB or persistent chat history.
- Switching tabs, minimizing, closing or leaving ends the session and clears the page's in-memory chat/media state.
- Room state is held in server memory only and expires after 30 minutes.

## Deploy on Render (phone-friendly)
1. Upload `server.js`, `package.json`, `render.yaml`, and the `public` folder to a GitHub repository.
2. In Render choose **New → Web Service** and connect the repository.
3. Use Node runtime, build command `npm install`, start command `npm start`.
4. Add environment variable `ROOM_PASSWORD` with a long private password. Do not use the example password for a real private conversation.
5. Deploy and open the generated `https://...onrender.com` address.
6. One person taps **Create room**, then **Copy invite link**. Share the link and send the password separately.
7. Both people open the HTTPS link and enter the same password. Allow camera and microphone access.

## Run locally in Termux
```sh
pkg update
pkg install nodejs-lts
unzip private-chat-video.zip
cd private_chat_updated
npm install
ROOM_PASSWORD='choose-a-long-password' npm start
```
Open `http://127.0.0.1:3000` for local testing. Camera/microphone permissions on mobile browsers generally require HTTPS or localhost. For another person to join over the internet, deploy it to an HTTPS host.

## Privacy and network limitations
- WebRTC encrypts media with SRTP and DataChannel traffic with DTLS. The signaling server sees room IDs, connection timing, IP/network metadata and temporary SDP/ICE information, but not chat text or audio/video content.
- The room password is checked by the server over HTTPS/WSS; the server operator can see the password. Use a strong password and share it separately from the invite link.
- STUN is configured, but no TURN relay is included. Some carrier, office or restrictive NAT networks may prevent a direct peer connection. A TURN service can improve connectivity but relays encrypted traffic and may have cost.
- A browser cannot guarantee an instantaneous leave notification during sudden power loss, app termination, network loss or OS suspension. The server detects broken connections via WebSocket heartbeat; mobile browsers may delay event delivery.
- `visibilitychange` ends the session whenever the page becomes hidden, including switching tabs or minimizing. This is intentionally strict and may also trigger when the browser temporarily backgrounds the page.
- No web app can prevent screenshots, screen recording, notification previews, or copies made by a participant. Clearing app memory cannot erase what the other person has already seen or captured.
- Render free instances may sleep. The first connection after inactivity can take longer. Server restart clears all room state.
- This is a privacy-focused casual app, not a professionally audited secure messenger. Use HTTPS and a long password.
