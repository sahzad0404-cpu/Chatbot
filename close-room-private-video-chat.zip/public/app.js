(() => {
"use strict";
const $ = id => document.getElementById(id);
const entry = $("entry"), session = $("session"), statusBox = $("status");
let ws = null, roomId = "", pc = null, channel = null, localStream = null;
let connected = false, ending = false, intentionalClose = false, pendingIce = [], queuedSignals = [];
let micOn = true, cameraOn = true;

function status(text, bad=false) {
  statusBox.textContent = text;
  statusBox.style.color = bad ? "#ff9cac" : "#c8d5ec";
}
function makeRoom() {
  const bytes = crypto.getRandomValues(new Uint8Array(12));
  return Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("");
}
function invite(id) {
  const url = new URL(location.href);
  url.search = ""; url.hash = "";
  url.searchParams.set("room", id);
  return url.toString();
}
function parseRoom(value) {
  const raw = value.trim();
  try {
    const url = new URL(raw);
    return url.searchParams.get("room") || raw;
  } catch { return raw; }
}
function setCallStatus(text, state="CONNECTING") {
  $("callStatus").textContent = text;
  $("statePill").textContent = state;
  $("statePill").style.color = state === "CONNECTED" ? "#72e0b1" : "#cbd9f7";
}
function clearMessages() {
  $("messages").replaceChildren();
  $("message").value = "";
  $("message").disabled = true;
  $("send").disabled = true;
}
function stopMedia() {
  if (localStream) localStream.getTracks().forEach(track => { try { track.stop(); } catch {} });
  localStream = null;
  $("localVideo").srcObject = null;
  $("remoteVideo").srcObject = null;
}
function disposeConnection() {
  if (channel) { try { channel.close(); } catch {} }
  channel = null;
  if (pc) { try { pc.ontrack = pc.onicecandidate = pc.onconnectionstatechange = null; pc.close(); } catch {} }
  pc = null;
  stopMedia();
  pendingIce = [];
  queuedSignals = [];
  connected = false;
}
function finish(message, showEntry=true, tellServer=true) {
  if (ending) return;
  ending = true;
  if (tellServer && ws && ws.readyState === WebSocket.OPEN) {
    try { ws.send(JSON.stringify({type:"leave"})); } catch {}
  }
  intentionalClose = true;
  if (ws) { try { ws.close(); } catch {} }
  ws = null;
  disposeConnection();
  clearMessages();
  session.classList.add("hidden");
  if (showEntry) entry.classList.remove("hidden");
  status(message, true);
  setCallStatus("Session ended", "ENDED");
}
function addBubble(text, mine) {
  const el = document.createElement("div");
  el.className = "bubble" + (mine ? " mine" : "");
  el.append(document.createTextNode(text));
  const time = document.createElement("time");
  time.textContent = new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"});
  el.append(time);
  $("messages").append(el);
  $("messages").scrollTop = $("messages").scrollHeight;
}
function sendSignal(type, payload) {
  if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify({type, payload}));
}
function sendChat(text) {
  if (!channel || channel.readyState !== "open") return false;
  channel.send(JSON.stringify({type:"message", text}));
  return true;
}
function setupChannel(ch) {
  channel = ch;
  ch.onopen = () => {
    if (ending) return;
    connected = true;
    setCallStatus("Peer-to-peer connection established", "CONNECTED");
    $("message").disabled = false;
    $("send").disabled = false;
  };
  ch.onmessage = event => {
    if (ending) return;
    try {
      const packet = JSON.parse(event.data);
      if (packet.type === "message" && typeof packet.text === "string" && packet.text.length <= 2000) addBubble(packet.text, false);
    } catch {}
  };
  ch.onclose = () => {
    if (!ending) finish("The private connection closed.", true, true);
  };
  ch.onerror = () => {
    if (!ending) finish("The message connection failed.", true, true);
  };
}
async function flushIce() {
  if (!pc?.remoteDescription) return;
  for (const candidate of pendingIce.splice(0)) {
    try { await pc.addIceCandidate(candidate); } catch {}
  }
}
async function handleSignal(data) {
  if (ending) return;
  if (!pc) { queuedSignals.push(data); return; }
  try {
    if (data.type === "offer") {
      await pc.setRemoteDescription(data.payload);
      await flushIce();
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      sendSignal("answer", pc.localDescription);
    } else if (data.type === "answer") {
      await pc.setRemoteDescription(data.payload);
      await flushIce();
    } else if (data.type === "ice" && data.payload) {
      if (pc.remoteDescription) await pc.addIceCandidate(data.payload);
      else pendingIce.push(data.payload);
    }
  } catch (error) {
    finish("Could not establish the peer connection. Please create a new room.", true, true);
  }
}
async function startPeer(initiator) {
  if (ending) return;
  try {
    localStream = await navigator.mediaDevices.getUserMedia({
      audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      video: { facingMode: "user", width: {ideal:1280}, height: {ideal:720}, frameRate: {ideal:30, max:30} }
    });
    $("localVideo").srcObject = localStream;
    pc = new RTCPeerConnection({
      iceServers: [{urls:"stun:stun.l.google.com:19302"}, {urls:"stun:stun1.l.google.com:19302"}]
    });
    localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
    pc.onicecandidate = event => { if (event.candidate) sendSignal("ice", event.candidate); };
    pc.ontrack = event => {
      $("remoteVideo").srcObject = event.streams[0];
      $("remotePlaceholder").classList.add("hidden");
      $("remoteVideo").play().catch(() => {});
    };
    pc.onconnectionstatechange = () => {
      if (!pc || ending) return;
      if (pc.connectionState === "connected") setCallStatus("Video and audio connected", "CONNECTED");
      if (pc.connectionState === "failed" || pc.connectionState === "disconnected") {
        finish("Peer connection lost. This session has ended.", true, true);
      }
    };
    for (const signal of queuedSignals.splice(0)) await handleSignal(signal);
    if (initiator) {
      setupChannel(pc.createDataChannel("private-chat", {ordered:true}));
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      sendSignal("offer", pc.localDescription);
    } else {
      pc.ondatachannel = event => setupChannel(event.channel);
    }
    setCallStatus("Camera ready · connecting directly", "CONNECTING");
  } catch (error) {
    const reason = error?.name === "NotAllowedError" ? "Camera or microphone permission was denied." :
      error?.name === "NotFoundError" ? "No camera or microphone was found." :
      "Could not start camera and microphone. Check browser permissions.";
    finish(reason, true, true);
  }
}

$("create").onclick = () => {
  roomId = makeRoom();
  $("room").value = roomId;
  $("copy").disabled = false;
  history.replaceState(null, "", invite(roomId));
  status("Room created. Copy the invite link and share the password separately.");
};
$("copy").onclick = async () => {
  const id = parseRoom($("room").value);
  if (!/^[a-f0-9]{24}$/.test(id)) return status("Create a room first.", true);
  const link = invite(id);
  try {
    await navigator.clipboard.writeText(link);
    status("Invite link copied. Send the password separately.");
  } catch {
    status("Clipboard access failed. Copy this invite link: " + link, true);
  }
};

const inviteRoom = new URL(location.href).searchParams.get("room");
if (inviteRoom && /^[a-f0-9]{24}$/.test(inviteRoom)) {
  $("room").value = inviteRoom;
  $("copy").disabled = false;
  status("Invite link detected. Enter the shared password.");
}

$("join").onclick = async () => {
  if (ending === false && ws) return;
  roomId = parseRoom($("room").value);
  const password = $("password").value;
  if (!/^[a-f0-9]{24}$/.test(roomId)) return status("Create a room or paste a valid invite link.", true);
  if (!password) return status("Enter the room password.", true);
  if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia || !window.RTCPeerConnection) {
    return status("Video calls need a modern browser and an HTTPS website.", true);
  }
  $("join").disabled = true;
  status("Connecting to the room…");
  ending = false; intentionalClose = false;
  try {
    const scheme = location.protocol === "https:" ? "wss:" : "ws:";
    ws = new WebSocket(`${scheme}//${location.host}/socket?room=${roomId}`);
    ws.onopen = () => ws.send(JSON.stringify({type:"join", password}));
    ws.onmessage = async event => {
      let data;
      try { data = JSON.parse(event.data); } catch { return; }
      if (data.type === "waiting") {
        entry.classList.add("hidden"); session.classList.remove("hidden");
        setCallStatus("Waiting for the other person to join…", "WAITING");
      } else if (data.type === "ready") {
        entry.classList.add("hidden"); session.classList.remove("hidden");
        setCallStatus("Both people are here · starting camera…", "CONNECTING");
        await startPeer(Boolean(data.initiator));
      } else if (["offer","answer","ice"].includes(data.type)) {
        await handleSignal(data);
      } else if (data.type === "ended") {
        finish(data.reason || "The other person ended the session.", true, false);
      } else if (data.type === "error") {
        finish(data.message || "Room unavailable.", true, false);
      }
    };
    ws.onerror = () => { if (!ending) finish("Could not connect to the room. Check the link and try again.", true, false); };
    ws.onclose = () => {
      if (!ending && !intentionalClose) finish("The room connection closed. This session has ended.", true, false);
    };
    $("password").value = "";
    history.replaceState(null, "", location.pathname);
  } catch {
    finish("Could not connect. Please try again.", true, false);
  } finally {
    $("join").disabled = false;
  }
};

$("sendForm").onsubmit = event => {
  event.preventDefault();
  const field = $("message");
  const text = field.value.trim();
  if (!text || text.length > 2000 || !sendChat(text)) return;
  addBubble(text, true);
  field.value = "";
};
$("leave").onclick = () => finish("You ended the session. The room is closed for both people.", true, true);
$("mute").onclick = () => {
  if (!localStream) return;
  micOn = !micOn;
  localStream.getAudioTracks().forEach(track => track.enabled = micOn);
  $("mute").textContent = micOn ? "Mute mic" : "Unmute mic";
  $("mute").classList.toggle("off", !micOn);
};
$("camera").onclick = () => {
  if (!localStream) return;
  cameraOn = !cameraOn;
  localStream.getVideoTracks().forEach(track => track.enabled = cameraOn);
  $("camera").textContent = cameraOn ? "Turn camera off" : "Turn camera on";
  $("camera").classList.toggle("off", !cameraOn);
  $("localVideo").style.opacity = cameraOn ? "1" : ".2";
};

function leaveOnHide() {
  if (!ws || ending) return;
  finish("This page was hidden. The session has ended.", true, true);
}
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "hidden") leaveOnHide();
});
window.addEventListener("pagehide", () => {
  if (ws && !ending) {
    try { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({type:"leave"})); } catch {}
    try { ws.close(); } catch {}
  }
  disposeConnection();
  clearMessages();
});
window.addEventListener("beforeunload", () => {
  if (ws && ws.readyState === WebSocket.OPEN) {
    try { ws.send(JSON.stringify({type:"leave"})); } catch {}
  }
  disposeConnection();
});
})();