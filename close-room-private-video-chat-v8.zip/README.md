# CloseRoom V8

Ephemeral two-person WebRTC video call and private in-call messaging.

## V8 interface changes
- One connection-status pill at top-left and local `You` preview at top-right.
- Glass-style floating message cards: maximum three, newest at the bottom, each expires after 40 seconds. A fourth removes the oldest.
- Quick Message is a separate state: hides the normal message launcher and call controls, keeps the call video above a single composer, and returns to video after a successful send or composer close.
- Full Chat is a separate full-screen conversation with a small tappable video preview. Open it with the Messages button or swipe up on the video.
- The legacy slide-up chat drawer has been removed so there is only one full-chat experience.
- Browser keyboard resizing is requested with `interactive-widget=resizes-content`; there is no JavaScript visual-viewport height arithmetic.
- Mute/unmute, camera on/off, camera flip, fullscreen, and end-call controls remain available on the normal call screen.

## Deploy on Render from a ZIP
Upload this ZIP to the repository root. If GitHub adds a suffix such as `-1`, the V8 wildcard build command below still matches it as long as there is only one V8 ZIP in the repository.

Build command:
```bash
unzip -o close-room-private-video-chat-v8*.zip -d . && npm install
```

Start command:
```bash
npm start
```

Set `ROOM_PASSWORD` in Render environment variables to a long unique shared password. Do not use the example password in production.

## Important
- Requires HTTPS, camera/microphone permission, and a modern browser.
- Uses public STUN servers only; some restrictive mobile networks may require TURN for reliable connectivity.
- No permanent chat history is stored by the client. A server/session interruption ends the call.
- Browser keyboard and native fullscreen behaviour differs across Android devices and keyboards. Test with two phones before relying on it.
- The app requests browser viewport resizing when the software keyboard opens; browsers that ignore `interactive-widget=resizes-content` may behave differently.
