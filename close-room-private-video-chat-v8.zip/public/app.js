(() => {
"use strict";
const $ = id => document.getElementById(id);
const entry = $("entry"), session = $("session"), statusBox = $("status");
let ws = null, roomId = "", pc = null, channel = null, localStream = null;
let ending = false, intentionalClose = false, pendingIce = [], queuedSignals = [];
let micOn = false, cameraOn = true, facingMode = "user", quickComposerOpen = false, fullChatOpen = false;
let quickKeyboardSeen = false, keyboardCloseTimer = null;
const toastTimers = new Set();
// Keep floating messages attached to the video stage in every screen state.
$("callstage").appendChild($("toastStack"));

function status(text, bad=false) { statusBox.textContent = text; statusBox.style.color = bad ? "#ff9cac" : "#c8d5ec"; }
function makeRoom() {
  const bytes = crypto.getRandomValues(new Uint8Array(12));
  return Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("");
}
function invite(id) {
  const url = new URL(location.href); url.search = ""; url.hash = ""; url.searchParams.set("room", id); return url.toString();
}
function parseRoom(value) {
  const raw = value.trim();
  try { const url = new URL(raw); return url.searchParams.get("room") || raw; } catch { return raw; }
}
function setCallStatus(text) { $("callStatus").textContent = text; const island = $("islandStatus"); if (island) island.textContent = text; }
function clearMessages() {
  $("fullMessages").replaceChildren(); $("toastStack").replaceChildren();
  for (const timer of toastTimers) clearTimeout(timer);
  toastTimers.clear(); $("quickMessage").value = ""; $("quickMessage").disabled = true; $("quickSend").disabled = true; $("fullMessage").disabled = true; $("fullSend").disabled = true;
  $("unread").classList.add("hidden"); closeQuickComposer(); session.classList.remove("compose-mode","chat-mode"); fullChatOpen = false;
}
function openQuickComposer() {
  if (ending || fullChatOpen) return;
  quickKeyboardSeen = false; quickComposerOpen = true; session.classList.add("compose-mode");
  requestAnimationFrame(() => setTimeout(() => { if (quickComposerOpen) $("quickMessage").focus({preventScroll:true}); }, 80));
}
function closeQuickComposer() {
  quickComposerOpen = false; quickKeyboardSeen = false; clearTimeout(keyboardCloseTimer);
  if ($("quickMessage")) { $("quickMessage").blur(); $("quickMessage").value = ""; }
  session.classList.remove("compose-mode");
}
function showFullChat() {
  if (ending) return;
  closeQuickComposer(); fullChatOpen = true; session.classList.add("chat-mode");
  $("unread").classList.add("hidden");
  setTimeout(() => { $("fullMessage").focus(); $("fullMessages").scrollTop = $("fullMessages").scrollHeight; }, 120);
}
function returnToVideo() {
  fullChatOpen = false;
  if (document.activeElement && document.activeElement.matches('input,textarea')) document.activeElement.blur();
  session.classList.remove("chat-mode");
}
function showToast(text, mine) {
  if (fullChatOpen) return;
  const el = document.createElement("button"); el.type = "button"; el.className = "toast" + (mine ? " mine" : "");
  const who = document.createElement("div"); who.className = "toast-name"; who.textContent = mine ? "You" : "Message";
  const body = document.createElement("div"); body.className = "toast-text"; body.textContent = text;
  const hint = document.createElement("div"); hint.className = "toast-hint"; hint.textContent = "Tap to reply";
  el.append(who, body, hint); el.onclick = openQuickComposer; $("toastStack").append(el);
  while ($("toastStack").children.length > 3) {
    const oldest = $("toastStack").firstElementChild;
    const oldTimer = oldest._expiryTimer; if (oldTimer) { clearTimeout(oldTimer); toastTimers.delete(oldTimer); }
    oldest.remove();
  }
  const timer = setTimeout(() => { el.remove(); toastTimers.delete(timer); }, 40000);
  el._expiryTimer = timer; toastTimers.add(timer);
}
function addBubble(text, mine) {
  const make = () => {
    const el = document.createElement("div"); el.className = "bubble" + (mine ? " mine" : ""); el.append(document.createTextNode(text));
    const time = document.createElement("time"); time.textContent = new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}); el.append(time); return el;
  };
  $("fullMessages").append(make()); $("fullMessages").scrollTop = $("fullMessages").scrollHeight;
  if (!fullChatOpen) { showToast(text, mine); if (!mine) $("unread").classList.remove("hidden"); }
}
function setMicButton() {
  $("mute").classList.toggle("off", !micOn);
  $("mute").querySelector("span:last-child").textContent = micOn ? "Mute" : "Unmute";
  $("mute").setAttribute("aria-label", micOn ? "Mute microphone" : "Unmute microphone");
}
function stopMedia() {
  if (localStream) localStream.getTracks().forEach(track => { try { track.stop(); } catch {} });
  localStream = null; $("localVideo").srcObject = null; $("remoteVideo").srcObject = null;
}
function disposeConnection() {
  if (channel) { try { channel.close(); } catch {} } channel = null;
  if (pc) { try { pc.ontrack = pc.onicecandidate = pc.onconnectionstatechange = pc.ondatachannel = null; pc.close(); } catch {} }
  pc = null; stopMedia(); pendingIce = []; queuedSignals = [];
}
function finish(message, showEntry=true, tellServer=true) {
  if (ending) return; ending = true;
  if (tellServer && ws && ws.readyState === WebSocket.OPEN) { try { ws.send(JSON.stringify({type:"leave"})); } catch {} }
  intentionalClose = true; if (ws) { try { ws.close(); } catch {} } ws = null;
  disposeConnection(); clearMessages(); session.classList.add("hidden"); if (showEntry) entry.classList.remove("hidden");
  status(message, true); setCallStatus("Session ended");
}
function sendSignal(type, payload) { if (ws?.readyState === WebSocket.OPEN) ws.send(JSON.stringify({type, payload})); }
function sendChat(text) {
  if (!channel || channel.readyState !== "open") return false;
  channel.send(JSON.stringify({type:"message", text})); return true;
}
function setupChannel(ch) {
  channel = ch;
  ch.onopen = () => { if (ending) return; setCallStatus("Connected · video and private chat are ready"); $("quickMessage").disabled = false; $("quickSend").disabled = false; $("fullMessage").disabled = false; $("fullSend").disabled = false; };
  ch.onmessage = event => {
    if (ending) return;
    try { const packet = JSON.parse(event.data); if (packet.type === "message" && typeof packet.text === "string" && packet.text.length <= 2000) addBubble(packet.text, false); } catch {}
  };
  ch.onclose = () => { if (!ending) finish("The private connection closed. The session has ended.", true, true); };
  ch.onerror = () => { if (!ending) finish("The message connection failed. The session has ended.", true, true); };
}
async function flushIce() {
  if (!pc?.remoteDescription) return;
  for (const candidate of pendingIce.splice(0)) { try { await pc.addIceCandidate(candidate); } catch {} }
}
async function handleSignal(data) {
  if (ending) return; if (!pc) { queuedSignals.push(data); return; }
  try {
    if (data.type === "offer") {
      await pc.setRemoteDescription(data.payload); await flushIce();
      const answer = await pc.createAnswer(); await pc.setLocalDescription(answer); sendSignal("answer", pc.localDescription);
    } else if (data.type === "answer") {
      await pc.setRemoteDescription(data.payload); await flushIce();
    } else if (data.type === "ice" && data.payload) {
      if (pc.remoteDescription) await pc.addIceCandidate(data.payload); else pendingIce.push(data.payload);
    }
  } catch { finish("Could not establish the peer connection. Create a new room and try again.", true, true); }
}
async function startPeer(initiator) {
  if (ending) return;
  try {
    localStream = await navigator.mediaDevices.getUserMedia({
      audio: {echoCancellation:true, noiseSuppression:true, autoGainControl:true},
      video: {facingMode:{ideal:facingMode}, width:{ideal:1920}, height:{ideal:1080}, frameRate:{ideal:30,max:30}}
    });
    localStream.getAudioTracks().forEach(track => track.enabled = false);
    micOn = false; setMicButton(); $("localVideo").srcObject = localStream;
    pc = new RTCPeerConnection({iceServers:[{urls:"stun:stun.l.google.com:19302"},{urls:"stun:stun1.l.google.com:19302"}]});
    localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
    pc.onicecandidate = event => { if (event.candidate) sendSignal("ice", event.candidate); };
    pc.ontrack = event => { $("remoteVideo").srcObject = event.streams[0]; $("remotePlaceholder").classList.add("hidden"); $("remoteVideo").play().catch(() => {}); };
    pc.onconnectionstatechange = () => {
      if (!pc || ending) return;
      if (pc.connectionState === "connected") setCallStatus("Connected · microphone muted");
      if (pc.connectionState === "failed" || pc.connectionState === "disconnected") finish("Peer connection lost. The session has ended.", true, true);
    };
    for (const signal of queuedSignals.splice(0)) await handleSignal(signal);
    if (initiator) {
      setupChannel(pc.createDataChannel("private-chat", {ordered:true}));
      const offer = await pc.createOffer(); await pc.setLocalDescription(offer); sendSignal("offer", pc.localDescription);
    } else pc.ondatachannel = event => setupChannel(event.channel);
    setCallStatus("Camera ready · connecting directly");
  } catch (error) {
    const reason = error?.name === "NotAllowedError" ? "Camera or microphone permission was denied." : error?.name === "NotFoundError" ? "No camera or microphone was found." : "Could not start camera and microphone. Check browser permissions.";
    finish(reason, true, true);
  }
}

$("create").onclick = async () => {
  roomId = makeRoom(); $("room").value = roomId; $("copy").disabled = false; history.replaceState(null, "", invite(roomId));
  const link = invite(roomId);
  try {
    await navigator.clipboard.writeText(link);
    status("Room ready · invite link copied. Share the password separately.");
  } catch {
    status("Room ready · tap Copy invite, then share the password separately.");
  }
};
$("copy").onclick = async () => {
  const id = parseRoom($("room").value); if (!/^[a-f0-9]{24}$/.test(id)) return status("Create a room first.", true);
  const link = invite(id);
  try { await navigator.clipboard.writeText(link); status("Invite link copied. Send the password separately."); }
  catch { status("Clipboard access failed. Copy this link: " + link, true); }
};
const inviteRoom = new URL(location.href).searchParams.get("room");
if (inviteRoom && /^[a-f0-9]{24}$/.test(inviteRoom)) { $("room").value = inviteRoom; $("copy").disabled = false; status("Invite link detected. Enter the shared password."); }

$("join").onclick = async () => {
  if (ws) return;
  roomId = parseRoom($("room").value); const password = $("password").value;
  if (!/^[a-f0-9]{24}$/.test(roomId)) return status("Create a room or paste a valid invite link.", true);
  if (!password) return status("Enter the room password.", true);
  if (!window.isSecureContext || !navigator.mediaDevices?.getUserMedia || !window.RTCPeerConnection) return status("Video calls need a modern browser and an HTTPS website.", true);
  $("join").disabled = true; status("Connecting to the room…"); ending = false; intentionalClose = false;
  try {
    const scheme = location.protocol === "https:" ? "wss:" : "ws:";
    ws = new WebSocket(`${scheme}//${location.host}/socket?room=${roomId}`);
    ws.onopen = () => ws.send(JSON.stringify({type:"join", password}));
    ws.onmessage = async event => {
      let data; try { data = JSON.parse(event.data); } catch { return; }
      if (data.type === "waiting") { entry.classList.add("hidden"); session.classList.remove("hidden"); setCallStatus("Waiting for the other person to join…"); }
      else if (data.type === "ready") { entry.classList.add("hidden"); session.classList.remove("hidden"); setCallStatus("Both people are here · starting camera…"); await startPeer(Boolean(data.initiator)); }
      else if (["offer","answer","ice"].includes(data.type)) await handleSignal(data);
      else if (data.type === "ended") finish(data.reason || "The other person ended the session.", true, false);
      else if (data.type === "error") finish(data.message || "Room unavailable.", true, false);
    };
    ws.onerror = () => { if (!ending) finish("Could not connect to the room. Check the link and try again.", true, false); };
    ws.onclose = () => { if (!ending && !intentionalClose) finish("The room connection closed. This session has ended.", true, false); };
    $("password").value = ""; history.replaceState(null, "", location.pathname);
  } catch { finish("Could not connect. Please try again.", true, false); }
  finally { $("join").disabled = false; }
};

function submitMessage(field) {
  const text = field.value.trim();
  if (!text || text.length > 2000 || !sendChat(text)) return false;
  addBubble(text, true); field.value = ""; return true;
}
$("quickForm").onsubmit = event => { event.preventDefault(); if (submitMessage($("quickMessage"))) { closeQuickComposer(); } };
$("fullSendForm").onsubmit = event => { event.preventDefault(); submitMessage($("fullMessage")); };
$("quickOpen").onclick = openQuickComposer;
$("quickCancel").onclick = closeQuickComposer;
$("backToVideo").onclick = returnToVideo;
$("callstage").onclick = event => { if (fullChatOpen && !event.target.closest(".toast")) returnToVideo(); };
let stageTouchY = null;
$("callstage").addEventListener("touchstart", e => { stageTouchY = e.touches[0]?.clientY ?? null; }, {passive:true});
$("callstage").addEventListener("touchend", e => {
  if (stageTouchY === null) return;
  const dy = e.changedTouches[0].clientY - stageTouchY;
  if (dy < -65) showFullChat();
  stageTouchY = null;
}, {passive:true});
$("quickMessage").addEventListener("keydown", e => { if (e.key === "Escape") closeQuickComposer(); });
$("quickMessage").addEventListener("blur", () => {
  // Losing focus closes Quick Message; the keyboard and composer leave together.
  setTimeout(() => {
    if (quickComposerOpen && document.activeElement !== $("quickMessage")) closeQuickComposer();
  }, 80);
});
$("mute").onclick = () => {
  if (!localStream) return; micOn = !micOn;
  localStream.getAudioTracks().forEach(track => track.enabled = micOn);
  setMicButton();
};
$("camera").onclick = () => {
  if (!localStream) return; cameraOn = !cameraOn;
  localStream.getVideoTracks().forEach(track => track.enabled = cameraOn);
  $("camera").classList.toggle("off", !cameraOn);
  $("camera").querySelector("span:last-child").textContent = cameraOn ? "Camera" : "Cam off";
  $("localVideo").style.opacity = cameraOn ? "1" : ".2";
};
$("flip").onclick = async () => {
  if (!localStream || !pc) return;
  const nextFacing = facingMode === "user" ? "environment" : "user";
  try {
    const nextStream = await navigator.mediaDevices.getUserMedia({video:{facingMode:{exact:nextFacing},width:{ideal:1920},height:{ideal:1080},frameRate:{ideal:30,max:30}},audio:false});
    const nextTrack = nextStream.getVideoTracks()[0];
    const sender = pc.getSenders().find(item => item.track?.kind === "video");
    if (!sender) throw new Error("Video sender unavailable");
    await sender.replaceTrack(nextTrack);
    const oldTrack = localStream.getVideoTracks()[0];
    if (oldTrack) { localStream.removeTrack(oldTrack); oldTrack.stop(); }
    localStream.addTrack(nextTrack); $("localVideo").srcObject = localStream; facingMode = nextFacing;
  } catch { setCallStatus("Could not switch camera on this device"); }
};
$("chatToggle").onclick = () => fullChatOpen ? returnToVideo() : showFullChat();
function isMobileViewport() {
  return window.matchMedia("(max-width: 760px), (pointer: coarse)").matches;
}
function updateFullscreenLabel() {
  const active = session.classList.contains("app-fullscreen") || !!document.fullscreenElement;
  $("fullscreen").querySelector("span:last-child").textContent = active ? "Exit" : "Full";
}
$("fullscreen").onclick = async () => {
  if (isMobileViewport()) {
    if (session.classList.contains("app-fullscreen")) {
      session.classList.remove("app-fullscreen");
      if (document.fullscreenElement) { try { await document.exitFullscreen(); } catch {} }
    } else {
      session.classList.add("app-fullscreen");
      try {
        if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
          await document.documentElement.requestFullscreen();
        }
      } catch {
        // Keep the app-level immersive layout when native fullscreen is unavailable.
      }
    }
    updateFullscreenLabel();
    return;
  }
  try {
    if (document.fullscreenElement) await document.exitFullscreen();
    else if (session.requestFullscreen) await session.requestFullscreen();
    else session.classList.toggle("app-fullscreen");
  } catch {
    session.classList.toggle("app-fullscreen");
  }
  updateFullscreenLabel();
};
document.addEventListener("fullscreenchange", updateFullscreenLabel);

$("leave").onclick = () => { if (window.confirm("End this private call for both people?")) finish("You ended the session. The room is closed for both people.", true, true); };

function leaveOnHide() { if (ws && !ending) finish("This page was hidden. The session has ended.", true, true); }
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "hidden") leaveOnHide(); });
window.addEventListener("pagehide", () => {
  if (ws && !ending) { try { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({type:"leave"})); } catch {} try { ws.close(); } catch {} }
  disposeConnection(); clearMessages();
});
window.addEventListener("beforeunload", () => {
  if (ws && ws.readyState === WebSocket.OPEN) { try { ws.send(JSON.stringify({type:"leave"})); } catch {} }
  disposeConnection();
});
})();
